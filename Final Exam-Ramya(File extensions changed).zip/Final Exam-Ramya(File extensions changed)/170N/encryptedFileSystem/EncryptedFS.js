const fs = require('fs');
const util = require('util');
const crypto = require("crypto");
const eccrypto = require("eccrypto");

const write = util.promisify(fs.writeFile);
const read = util.promisify(fs.readFile);

// A new random 32-byte private key.
let privateKey = eccrypto.generatePrivate();
// Corresponding uncompressed (65-byte) public key.
let publicKey = eccrypto.getPublic(privateKey);

// Create a variable representing the path to a .txt
const file1 = 'file.txt';
const file2 = 'enFile.txt';

function encryptContentAndSign(contentsFromFile){
    //get the enrypted content
    var encryptedContent = crypto.createHash("sha256").update(contentsFromFile).digest();

    //Sign the encrypted content and write it back to file 2
    eccrypto.sign(privateKey, encryptedContent).then(function(sig) {
        console.log("Signature in DER format:", sig);
        eccrypto.verify(publicKey, encryptedContent, sig).then(function() {
          console.log("Signature is OK");
        }).catch(function() {
          console.log("Signature is BAD");
        });
      });
      write(file2, encryptedContent);
}


async function readWrite() {

  // Write "test" to the file
  await write(file1, 'my name is ramya');

  // Log the contents to console
  const contentsFromFile = await read(file1, 'utf8');

  //encrypt the contents read from the file
  encryptContentAndSign(contentsFromFile);
}

readWrite();