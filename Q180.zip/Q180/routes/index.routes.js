const express = require('express')
const router = express.Router()
const HospitalC = require('./../hospital.js')

router.post("/register",HospitalC.registerAppointment)
router.put("/register",HospitalC.updateAppointment)
router.get("/register",HospitalC.getBillAmount)
router.delete("/register",HospitalC.deleteAppointment)
router.post("/calcBill",HospitalC.calculateBill)

module.exports = router;