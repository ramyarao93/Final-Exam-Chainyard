const Web3 = require('web3');
const contract = require('./build/contracts/Hospital.json')

const web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:7545'));
const address = contract.networks["5777"].address
let hospitalContract = new web3.eth.Contract(contract.abi, address);
let fromAddress = "0x4E5E3d4C0AB302Af91ffFDE480cfE5a2f2DDc14b";

exports.registerAppointment = async function(req,res){
    try{
        hospitalContract.methods.registerAppointment(req.body.name,req.body.id,req.body.date,req.body.time).send({from:fromAddress})
    }
    catch(err){
        res.send("Error in registering appointment")
    }
}

exports.updateAppointment = async function(req,res){
    try{
        hospitalContract.methods.updateAppointment(req.body.name,req.body.id,req.body.date,req.body.time).send({from:fromAddress,gas:'9000000',gasPrice:'1'})
    }
    catch(err){
        res.send("Error in updating appointment")
    }
}

exports.deleteAppointment = async function(req,res){
    try{
        hospitalContract.methods.deleteAppointment(req.body.name,req.body.id).send({from:fromAddress})
    }
    catch(err){
        res.send("Error in deleting appointment")
    }
}

exports.calculateBill = async function(req,res){
    try{
        hospitalContract.methods.calculateBill(req.body.name,req.body.id).send({from:fromAddress})
    }
    catch(err){
        res.send("Error in calculating bill")
    }
}

exports.getBillAmount = async function(req,res){
    try{
        hospitalContract.methods.getBillAmount(req.body.name,req.body.id).send({from:fromAddress})
    }
    catch(err){
        res.send("Error in retreiving bill amount")
    }
}