const Migrations = artifacts.require("Hospital");

module.exports = function(deployer) {
  deployer.deploy(Migrations);
};
