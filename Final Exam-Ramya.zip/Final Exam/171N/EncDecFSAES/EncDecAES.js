const fs = require('fs');
const util = require('util');

const write = util.promisify(fs.writeFile);
const read = util.promisify(fs.readFile);

// Nodejs encryption with CTR
const crypto = require('crypto');
const algorithm = 'aes-256-cbc';
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);

// Create a variable representing the path to a .txt
const file1 = 'file.txt';

//Encrypt the file using

function encrypt(text) {
    let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
}

//Decrypt the file

function decrypt(text) {
    let iv = Buffer.from(text.iv, 'hex');
    let encryptedText = Buffer.from(text.encryptedData, 'hex');
    let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
}

async function readWrite() {
    // Write "test" to the file
    await write(file1, 'my name is ramya');

    // Log the contents to console
    const contentsFromFile = await read(file1, 'utf8');

    var encText = encrypt(contentsFromFile);
    console.log(encText);
    console.log(decrypt(encText));

}

readWrite()
