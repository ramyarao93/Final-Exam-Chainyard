//Defind object 1
const myObj1={
    restaurentId : 1,
    restaurantName : "chipotle",
    formattedAddress : "Morrisville, NC"
}

//Define object 2
const myObj2={
    type : "countryCode",
    value : "+91"
}

//Loop through the object and extract the key and value pair
function printKeyValue(input){
    for(p in input) {
        if (input.hasOwnProperty(p)) {
            console.log (p + " : " + input[p])
        }
    }
}

console.log("OBJECT 1")
printKeyValue(myObj1);
console.log("OBJECT 2")
printKeyValue(myObj2);