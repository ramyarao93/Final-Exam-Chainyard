const express = require('express')
const router = express.Router()
const restaurent = require('../models/restaurent.model')
const m = require('../helpers/middlewares')

/* All restaurents */
router.get('/', async (req, res) => {
    await restaurent.getRestaurents()
    .then(restaurents => res.json(restaurents))
    .catch(err => {
        if (err.status) {
            res.status(err.status).json({ message: err.message })
        } else {
            res.status(500).json({ message: err.message })
        }
    })
    console.log(restaurents);
})


/* A restaurent by id */
router.get('/:id', m.mustBeInteger, async (req, res) => {
    const id = req.params.id
    await restaurent.getRestaurent(id)
    .then(restaurent => res.json(restaurent))
    .catch(err => {
        if (err.status) {
            res.status(err.status).json({ message: err.message })
        } else {
            res.status(500).json({ message: err.message })
        }
    })
})

/* Insert a new restaurent */
router.post('/', m.checkFieldsPost, async (req, res) => {
    await restaurent.insertRestaurent(req.body)
    .then(restaurent => res.status(201).json({
        message: `The restaurent #${restaurent.id} has been created`,
        content: restaurent
    }))
    .catch(err => res.status(500).json({ message: err.message }))
})

/* Delete a restaurent */
router.delete('/:id', m.mustBeInteger, async (req, res) => {
    const id = req.params.id
    
    await restaurent.deleteRestaurent(id)
    .then(restaurent => res.json({
        message: `The restaurent #${id} has been deleted`
    }))
    .catch(err => {
        if (err.status) {
            res.status(err.status).json({ message: err.message })
        }
        res.status(500).json({ message: err.message })
    })
})

// Routes
module.exports = router