// Words to match
let words = ["war","eat","donut","pizza","raw","ate","apizz"]

// The output object
let anagrams = {};

function sortWord(word) {
    arr = word.split("");
    arr.sort();
    splitedWord = arr.join("");
    return splitedWord
}

for (let i in words) {
    let word = words[i];

    // sort the word like you've already described
    let sorted = sortWord(word);

    // If the key already exists, we just push
    // the new word on the the array
    if (anagrams[sorted] != null) {
        anagrams[sorted].push(word);
    }
    // Otherwise we create an array with the word
    // and insert it into the object
    else {
        anagrams[sorted] = [word];
    }
}

// Output result
for (let sorted in anagrams) {
    let words = anagrams[sorted];
    let sep = ",";
    let openingQuote = "'"
    let closingQuote = "'"
    let output = ""
    for (let n in words) {
        output += openingQuote + words[n] + closingQuote + sep;
        sep = "";
    }
    console.log('('+output+')') 
}