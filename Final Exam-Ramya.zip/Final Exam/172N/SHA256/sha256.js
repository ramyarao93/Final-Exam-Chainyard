const fs = require('fs');
const util = require('util');
const crypto = require("crypto");
const eccrypto = require("eccrypto");

const write = util.promisify(fs.writeFile);
const read = util.promisify(fs.readFile);

// Create a variable representing the path to a .txt
const file1 = 'file.txt';
const file2 = 'enFile.txt'

//Create the hash of the text read from the file
function createHash(text){
    const hash = crypto.createHash('sha256').update(text).digest('hex')
    write(file2,hash);

    return hash
}

async function readWrite() {

    // Write "test" to the file
    await write(file1, 'my name is ramya');

    // Log the contents to console
    const contentsFromFile = await read(file1, 'utf8');

    //encrypt the contents read from the file
    var hash = createHash(contentsFromFile);
    console.log('Hash : ',hash);
}

readWrite();