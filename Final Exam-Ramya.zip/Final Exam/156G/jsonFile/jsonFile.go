package main

import (
    "fmt"
	"encoding/json"
	"io/ioutil"
	"os"
)

type JSON struct {
    Data string
}

func main() {
	data, err := ioutil.ReadFile("file.txt")
    if err != nil {
        fmt.Println("File reading error", err)
        return
    }
	fmt.Println("Contents of file:", string(data))

    a := &JSON{string(data)}

    out, err := json.Marshal(a)
    if err != nil {
        panic (err)
    }

	fmt.Println(string(out))
	
	fs, err := os.Create("output.txt")
    if err != nil {
        fmt.Println(err)
        return
    }
    _, err = fs.WriteString(string(out))
    if err != nil {
        fmt.Println(err)
        fs.Close()
        return
    }
}